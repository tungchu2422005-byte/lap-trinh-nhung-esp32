
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// ================= PIN =================
#define MQ2_PIN 34
#define DHT_PIN 4
#define DHT_TYPE DHT22

#define FAN_PIN 18
#define PUMP_PIN 19

// ================= WIFI =================
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ================= MQTT =================
const char* mqtt_server = "broker.emqx.io";
const int mqtt_port = 1883;

const char* topicGas = "giadinh/baochay/gas";
const char* topicTemp = "giadinh/baochay/temperature";

const char* topicFanCmd = "giadinh/baochay/fan/cmd";
const char* topicPumpCmd = "giadinh/baochay/pump/cmd";
const char* topicMode = "giadinh/baochay/mode";

const char* topicFanState = "giadinh/baochay/fan/state";
const char* topicPumpState = "giadinh/baochay/pump/state";
const char* topicAlarm = "giadinh/baochay/alarm";

// ================= OBJECT =================
DHT dht(DHT_PIN, DHT_TYPE);

WiFiClient espClient;
PubSubClient mqtt(espClient);

// ================= DATA STRUCTURE =================
struct SensorData {
  float gas;
  float temperature;
};

// ================= QUEUE =================
QueueHandle_t dataQueue;
QueueHandle_t dataAlert;

// ================= CONTROL =================
volatile bool manualMode = false;
volatile bool manualFan = false;
volatile bool manualPump = false;

volatile bool fanState = false;
volatile bool pumpState = false;

// Ngưỡng cảnh báo
const float GAS_THRESHOLD = 50.0;
const float TEMP_THRESHOLD = 50.0;

// ================= MQTT CALLBACK =================
void mqttCallback(char* topic, byte* payload,
                  unsigned int length) {

  char message[20];

  if (length >= sizeof(message)) return;

  memcpy(message, payload, length);
  message[length] = '\0';

  if (strcmp(topic, topicFanCmd) == 0) {
    manualMode = true;

    if (strcmp(message, "ON") == 0)
      manualFan = true;
    else if (strcmp(message, "OFF") == 0)
      manualFan = false;
  }

  else if (strcmp(topic, topicPumpCmd) == 0) {
    manualMode = true;

    if (strcmp(message, "ON") == 0)
      manualPump = true;
    else if (strcmp(message, "OFF") == 0)
      manualPump = false;
  }

  else if (strcmp(topic, topicMode) == 0) {
    if (strcmp(message, "AUTO") == 0)
      manualMode = false;

    else if (strcmp(message, "MANUAL") == 0)
      manualMode = true;
  }
}

// ================= TASK 1: READ SENSOR =================
void TaskReadData(void *pvParameters) {

  SensorData data;

  for (;;) {

    int rawGas = analogRead(MQ2_PIN);

    // Quy đổi giá trị ADC thành phần trăm tương đối
    data.gas = (rawGas * 100.0) / 4095.0;

    data.temperature = dht.readTemperature();

    if (isnan(data.temperature)) {
      Serial.println("Loi doc DHT22!");
      vTaskDelay(pdMS_TO_TICKS(2000));
      continue;
    }

    // Hiển thị dữ liệu Serial
    Serial.println("----------------------");

    Serial.print("Gas: ");
    Serial.print(data.gas);
    Serial.println(" %");

    Serial.print("Temperature: ");
    Serial.print(data.temperature);
    Serial.println(" C");

    // Gửi dữ liệu vào hai Queue
    xQueueSend(dataQueue, &data, 0);
    xQueueSend(dataAlert, &data, 0);

    vTaskDelay(pdMS_TO_TICKS(2000));
  }
}

// ================= TASK 2: SEND MQTT =================
void TaskSendData(void *pvParameters) {

  SensorData data;

  WiFi.begin(ssid, password);

  mqtt.setServer(mqtt_server, mqtt_port);
  mqtt.setCallback(mqttCallback);

  for (;;) {

    // Kết nối WiFi
    if (WiFi.status() != WL_CONNECTED) {

      Serial.println("Dang ket noi WiFi...");

      WiFi.reconnect();

      vTaskDelay(pdMS_TO_TICKS(3000));
      continue;
    }

    // Kết nối MQTT
    if (!mqtt.connected()) {

      Serial.println("Dang ket noi MQTT...");

      if (mqtt.connect("ESP32_BaoChay_Lab3")) {

        Serial.println("MQTT Connected!");

        mqtt.subscribe(topicFanCmd);
        mqtt.subscribe(topicPumpCmd);
        mqtt.subscribe(topicMode);
      }
      else {
        vTaskDelay(pdMS_TO_TICKS(3000));
        continue;
      }
    }

    mqtt.loop();

    // Nhận dữ liệu từ dataQueue
    if (xQueueReceive(dataQueue, &data,
                      pdMS_TO_TICKS(100)) == pdTRUE) {

      char gasStr[16];
      char tempStr[16];

      snprintf(gasStr, sizeof(gasStr), "%.1f", data.gas);
      snprintf(tempStr, sizeof(tempStr), "%.1f", data.temperature);

      // Gửi dữ liệu lên MQTT Broker
      mqtt.publish(topicGas, gasStr);
      mqtt.publish(topicTemp, tempStr);

      Serial.println("Da gui du lieu len MQTT!");
    }

    // Gửi trạng thái thiết bị
    mqtt.publish(topicFanState, fanState ? "ON" : "OFF");
    mqtt.publish(topicPumpState, pumpState ? "ON" : "OFF");

    vTaskDelay(pdMS_TO_TICKS(100));
  }
}

// ================= TASK 3: ALERT =================
void TaskAlert(void *pvParameters) {

  SensorData data;

  for (;;) {

    // Nhận dữ liệu từ dataAlert
    if (xQueueReceive(dataAlert, &data,
                      portMAX_DELAY) == pdTRUE) {

      bool newFan;
      bool newPump;

      if (manualMode) {

        // Chế độ điều khiển thủ công
        newFan = manualFan;
        newPump = manualPump;
      }
      else {

        // Chế độ tự động
        newFan = (data.gas >= GAS_THRESHOLD);
        newPump = (data.temperature >= TEMP_THRESHOLD);
      }

      // Điều khiển LED mô phỏng
      fanState = newFan;
      pumpState = newPump;

      digitalWrite(FAN_PIN, fanState ? HIGH : LOW);
      digitalWrite(PUMP_PIN, pumpState ? HIGH : LOW);

      // Kiểm tra cảnh báo
      if (data.gas >= GAS_THRESHOLD ||
          data.temperature >= TEMP_THRESHOLD) {

        Serial.println("CANH BAO CHAY!");
      }

      Serial.print("Quat: ");
      Serial.println(fanState ? "BAT" : "TAT");

      Serial.print("May bom: ");
      Serial.println(pumpState ? "BAT" : "TAT");
    }
  }
}

// ================= SETUP =================
void setup() {

  Serial.begin(115200);

  dht.begin();

  pinMode(MQ2_PIN, INPUT);
  pinMode(FAN_PIN, OUTPUT);
  pinMode(PUMP_PIN, OUTPUT);

  digitalWrite(FAN_PIN, LOW);
  digitalWrite(PUMP_PIN, LOW);

  analogReadResolution(12);

  // Tạo hai Queue
  dataQueue = xQueueCreate(10, sizeof(SensorData));
  dataAlert = xQueueCreate(10, sizeof(SensorData));

  if (dataQueue == NULL || dataAlert == NULL) {
    Serial.println("Loi tao Queue!");
    while (1) delay(1000);
  }

  // Tạo Task đọc cảm biến - Core 1
  xTaskCreatePinnedToCore(
    TaskReadData,
    "ReadData",
    4096,
    NULL,
    2,
    NULL,
    1
  );

  // Tạo Task truyền MQTT - Core 0
  xTaskCreatePinnedToCore(
    TaskSendData,
    "SendData",
    8192,
    NULL,
    1,
    NULL,
    0
  );

  // Tạo Task cảnh báo - Core 1
  xTaskCreatePinnedToCore(
    TaskAlert,
    "Alert",
    4096,
    NULL,
    2,
    NULL,
    1
  );

  Serial.println("He thong FreeRTOS da khoi dong!");
}

// ================= LOOP =================
void loop() {
  vTaskDelay(pdMS_TO_TICKS(1000));
}
